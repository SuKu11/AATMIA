import './App.css';
import React, { useContext } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginForm from './Components/LoginComponent/LoginForm';
import Main from "./Components/MainComponent/Main";
import AppContext from './ContextComponent/AppContext';
import TopAppBar from './Components/AppBarComponent/TopAppBar';

function App() {
  const { isAuth } = useContext(AppContext);
  return (
    <Router>
      {isAuth && <TopAppBar />} {/* Show Topbar when isAuth is true */}
      <Routes>
        <Route path="/" element={<LoginForm />} />
        {isAuth && <Route path="/page" element={<Main />} />} {/* Only show Main when isAuth is true */}
      </Routes>
    </Router>
  );
}

export default App;
