import React, { useState, useContext } from "react";
import "../MainComponent/MainStyle.css";
import {
  Card,
  CardContent,
  Typography,
  Button,
  // AppBar,
  // Toolbar,
  // Menu,
  // MenuItem,
  TextField,
  InputAdornment,
  CardActions
} from "@mui/material";
import AppContext from "../../ContextComponent/AppContext";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";

const MockData = [
  {
    college_name: "IIT Madras",
    course: "data science",
    description: "lorem ipsum",
    reg_user: 0,
  },
  {
    college_name: "SRMS",
    course: "react",
    description: "lorem ipsum",
    reg_user: 1,
  },
  {
    college_name: "PSG",
    course: "Angular",
    description: "lorem ipsum",
    reg_user: 0,
  },
  {
    college_name: "CIT",
    course: "Machine Learning",
    description: "lorem ipsum",
    reg_user: 4,
  },
  {
    college_name: "Harvard School",
    course: "Management studies",
    description: "lorem ipsum",
    reg_user: 2,
  },
  {
    college_name: "SRMS",
    course: "react",
    description: "lorem ipsum",
    reg_user: 1,
  },
  {
    college_name: "PSG",
    course: "Angular",
    description: "lorem ipsum",
    reg_user: 0,
  },
  {
    college_name: "CIT",
    course: "Machine Learning",
    description: "lorem ipsum",
    reg_user: 4,
  },
  {
    college_name: "Harvard School",
    course: "Management studies",
    description: "lorem ipsum",
    reg_user: 2,
  },
];

const lightColors = [
  "#FADBD8",
  "#D6EAF8",
  "#D4EFDF",
  "#FCF3CF",
  "#E8DAEF",
  "#FDEDEC",
];

export default function Main() {
  const [searchTerm, setSearchTerm] = useState("");

  const {
    registrationCount,
    setRegistrationCount,
    selectedCards,
    setSelectedCards,
  } = useContext(AppContext);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleRegisterClick = (index) => {
    setSelectedCards((prevSelectedCards) => {
      const newData = [...MockData];
      const isSelected = prevSelectedCards.includes(index);

      if (isSelected) {
        newData[index].reg_user = Math.max(0, newData[index].reg_user - 1);
        setRegistrationCount((prevCount) => prevCount - 1);
        return prevSelectedCards.filter((cardIndex) => cardIndex !== index);
      } else {
        if (registrationCount === 3) {
          return prevSelectedCards;
        }
        newData[index].reg_user = newData[index].reg_user + 1;
        setRegistrationCount((prevCount) => prevCount + 1);
        return [...prevSelectedCards, index];
      }
    });
  };

  const filteredData = MockData.filter((data) => {
    const { college_name, course } = data;
    const searchQuery = searchTerm.toLowerCase();
    return (
      college_name.toLowerCase().includes(searchQuery) ||
      course.toLowerCase().includes(searchQuery)
    );
  });

  return (
    <div className="edu-main-page">
      <div>
        <div style={{ display: "flex", justifyContent: "center" }}>
          <TextField
            type="text"
            placeholder="Search"
            value={searchTerm}
            onChange={handleSearchChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchOutlinedIcon />
                </InputAdornment>
              ),
            }}
          />
        </div>
        {registrationCount === 3 ? (null):(<div style={{color:"green"}}>
          <h2> All Active Courses</h2>
         
        </div>)}

        {registrationCount === 3 ? (
          <div className="message-container" style={{marginTop:"40px"}}>
            <Typography variant="body1" textAlign={"center"}>
              You have reached the maximum number of registrations for your free
              subscription. Please upgrade to premium to register for additional
              courses.
            </Typography>
          </div>
        ) : (
          
          <div className="card-container">
         { filteredData.map((data, index) => {
            const isSelected = selectedCards.includes(index);
            const cardColor = isSelected
              ? lightColors[index % lightColors.length]
              : "";

            return (
            
              <Card
                key={index}
                style={{ backgroundColor: cardColor, marginTop: "20px" }}
              >
                <CardContent>
                  <Typography
                    variant="subtitle2"
                    color="green"
                    style={{ float: "right" }}
                  >
                    Registered Users: {data.reg_user}
                  </Typography>
                  <Typography variant="h5" component="div">
                    {data.course}
                  </Typography>
                  <Typography variant="subtitle1" color="text.secondary">
                    {data.college_name}
                  </Typography>
                  <Typography variant="body2">{data.description}</Typography>
                </CardContent>
                
                <CardActions>
                <div className="button-container">
                  <Button
                    variant={isSelected ? "contained" : "outlined"}
                    onClick={() => handleRegisterClick(index)}
                  >
                    {isSelected ? "Unregister" : "Register"}
                  </Button>
                </div>
                </CardActions>
              </Card>
             
            );
          })
        }
       </div> )}
      </div>
    </div>
  );
}
