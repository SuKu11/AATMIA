import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Container from '@mui/material/Container';
import "../LoginComponent/LoginFormStyle.css";
import { Button } from '@mui/material';
import AppContext from '../../ContextComponent/AppContext';


const LoginForm = () => {
  const { setIsAuth, setUserName, userName } = useContext(AppContext);

  const navigate = useNavigate();

  const handleChange = (event) => {
    setUserName(event.target.value);
  };

  const handleSubmit = () => {
    if (userName.trim() !== '') {
      navigate('/page'); 
      setIsAuth(true);
    }
  };

  const isButtonDisabled = userName.trim() === '';

  return (
    <div className="login-page">
        <Container maxWidth="sm">
        <Card sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <CardContent  sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <h2>Welcome</h2>
            <input
              type="text"
              value={userName}
              onChange={handleChange}
              placeholder="Enter your name or number"
              className="center-input"
            />
          </CardContent>
          <CardActions className="center-button">
            <Button
              disabled={isButtonDisabled}
              onClick={handleSubmit}
              className="login-button"
            >
              Login
            </Button>
          </CardActions>
    </Card>
    </Container>
    </div>
  );
};

export default LoginForm;
