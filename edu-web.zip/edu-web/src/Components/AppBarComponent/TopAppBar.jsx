import React, { useState, useContext } from "react";
import {
  AppBar as MuiAppBar,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Card,
  CardContent,
  Button,
} from "@mui/material";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";
import AppContext from "../../ContextComponent/AppContext";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
const MockData = [
  {
    college_name: "IIT Madras",
    course: "data science",
    description: "lorem ipsum",
    reg_user: 0,
  },
  {
    college_name: "SRMS",
    course: "react",
    description: "lorem ipsum",
    reg_user: 1,
  },
  {
    college_name: "PSG",
    course: "Angular",
    description: "lorem ipsum",
    reg_user: 0,
  },
  {
    college_name: "CIT",
    course: "Machine Learning",
    description: "lorem ipsum",
    reg_user: 4,
  },
  {
    college_name: "Harvard School",
    course: "Management studies",
    description: "lorem ipsum",
    reg_user: 2,
  },
  {
    college_name: "SRMS",
    course: "react",
    description: "lorem ipsum",
    reg_user: 1,
  },
  {
    college_name: "PSG",
    course: "Angular",
    description: "lorem ipsum",
    reg_user: 0,
  },
  {
    college_name: "CIT",
    course: "Machine Learning",
    description: "lorem ipsum",
    reg_user: 4,
  },
  {
    college_name: "Harvard School",
    course: "Management studies",
    description: "lorem ipsum",
    reg_user: 2,
  },
];

function TopAppBar() {
  const [anchorEl, setAnchorEl] = useState(null);
  const { userName, registrationCount, selectedCards, setSelectedCards, setRegistrationCount } =
    useContext(AppContext);
  const [modalOpen, setModalOpen] = useState(false);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setModalOpen(true);
  };
  const handleCloseModal = () => {
    setModalOpen(false);
  };

  const handleRemoveCard = (index) => {
    console.log(index);
    const updatedSelectedCards = selectedCards.filter((cardIndex) => cardIndex !== index);
    setSelectedCards(updatedSelectedCards);
    setRegistrationCount(updatedSelectedCards.length);
  };
  console.log(selectedCards);
  return (
    <MuiAppBar position="static" color="transparent">
      <Toolbar style={{ display: "flex", justifyContent: "space-between" }}>
        <Typography variant="h6" component="div">
          EDU-APP
        </Typography>
        <div style={{ display: "flex", alignItems: "center" }}>
          <Typography variant="body2" component="div" color="inherit">
            {userName}
          </Typography>
          <IconButton
            aria-controls="profile-menu"
            aria-haspopup="true"
            onClick={handleClick}
            color="inherit"
          >
            <AccountCircleOutlinedIcon />
          </IconButton>
          <Menu
            id="profile-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem onClick={handleClose}>Dashboard</MenuItem>
            <MenuItem style={{color:"blue"}}>Free Balance {3 - registrationCount}</MenuItem>
          </Menu>
        </div>
      </Toolbar>
      <Dialog open={modalOpen} onClose={handleClose}>
        <DialogTitle>Active Classes</DialogTitle>
        <DialogContent>
          {selectedCards.length > 0 ? (
            selectedCards.map((index) => {
              const data = MockData[index];
              return (
                <Card key={index}>
                  <CardContent>
                    <Typography variant="h6" component="h3">
                      {data.college_name}
                    </Typography>
                    <Typography variant="subtitle1" component="p">
                      Course: {data.course}
                    </Typography>
                    <Typography variant="body2" component="p">
                      {data.description}
                    </Typography>
                    <Button onClick={() => handleRemoveCard(index)}>
                      Remove
                    </Button>
                  </CardContent>
                </Card>
              );
            })
          ) : (
            <Typography variant="body1">
              You have not registered for any courses.
            </Typography>
          )}
        </DialogContent>

        <DialogActions>
          <Button onClick={handleCloseModal}>Close</Button>
        </DialogActions>
      </Dialog>
    </MuiAppBar>
  );
}

export default TopAppBar;
