import React, { useState } from 'react';
import AppContext from './AppContext';

const AppState = (props) => {

    const [isAuth, setIsAuth] = useState(false);
    const [userName, setUserName] = useState("");
    const [registrationCount, setRegistrationCount] = useState(0);
    const [selectedCards, setSelectedCards] = useState([]);


    return (
        <AppContext.Provider value={{
            isAuth,
            setIsAuth,
            userName, 
            setUserName, 
            registrationCount, 
            setRegistrationCount,
            selectedCards,
            setSelectedCards
        }}>
            {props.children}
        </AppContext.Provider>
    );
};

export default AppState;