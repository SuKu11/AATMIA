/* eslint-disable no-unused-vars */

import React, { useState, createContext } from 'react';

export const AppContext = createContext();

export default AppContext;
